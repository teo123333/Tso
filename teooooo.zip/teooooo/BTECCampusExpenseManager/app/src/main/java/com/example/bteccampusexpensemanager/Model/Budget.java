package com.example.bteccampusexpensemanager.Model;
public class Budget {
    private String category;
    private double amount;

    public Budget(String category, double amount) {
        this.category = category;
        this.amount = amount;
    }

    // Getters and Setters
    public String getCategory() { return category; }
    public double getAmount() { return amount; }

    public void setCategory(String category) { this.category = category; }
    public void setAmount(double amount) { this.amount = amount; }
}

