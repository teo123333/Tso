package com.example.bteccampusexpensemanager;

import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

public class DemoActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_table_layout);

    }

    public void handleClickButton(View view){
        EditText name = findViewById(R.id.edit_id);
        String myName=name.getText().toString().trim();
        if(TextUtils.isEmpty(myName)) {
            Toast.makeText(this, "Your name cannot be empty", Toast.LENGTH_SHORT).show();
            return;
        }
        String message ="Hello"+myName+"Welcome to my App";
        Toast.makeText(this,message,Toast.LENGTH_SHORT).show();
    }
}
