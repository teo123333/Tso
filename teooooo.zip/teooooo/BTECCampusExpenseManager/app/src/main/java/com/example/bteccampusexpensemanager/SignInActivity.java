package com.example.bteccampusexpensemanager;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.example.bteccampusexpensemanager.Model.User;
import com.example.bteccampusexpensemanager.SQLite.UserDb;

public class SignInActivity extends AppCompatActivity {
    private EditText edtUsername, edtPassword;
    private Button btnSignIn, btnSignUp;
    private UserDb userDb;
    private TextView tvError;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_signin);
        edtUsername = findViewById(R.id.edtUserNameSignIn);
        edtPassword = findViewById(R.id.edtPassSignIn);
        btnSignIn = findViewById(R.id.btnSignIn);
        btnSignUp = findViewById(R.id.btnResgister);
        tvError = findViewById(R.id.tvError);
        userDb = new UserDb(SignInActivity.this);
        btnSignIn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                login();
            }
        });
        btnSignUp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(SignInActivity.this, SignupActivity.class);
                startActivity(intent);
            }
        });
    }

    private void login() {
        String username = edtUsername.getText().toString().trim();
        String password = edtPassword.getText().toString().trim();
        if (TextUtils.isEmpty(username)) {
            edtUsername.setError("USERNAME can not be empty");
            return;
        }
        if (TextUtils.isEmpty(username)) {
            edtPassword.setError("Password can not be empty");
            return;
        }
        User infoUser = userDb.getSingleUser(username,password);
        assert infoUser !=null;
        if (infoUser.getEmail() !=null && infoUser.getPhone() !=null){
         tvError.setText("");
         Intent intent = new Intent(SignInActivity.this, MenuActivity.class);
         startActivity(intent);
         finish();
        }else{
            tvError.setText("Account invalid");
            return;
        }
    }
}
