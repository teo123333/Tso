package com.example.bteccampusexpensemanager;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

public class LoginActivity extends AppCompatActivity {
    private EditText mUsername;
    private EditText mPassword;
    private Button submitLogin;
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        //Load View\
        setContentView(R.layout.activity_login);
       // setContentView(R.layout.activity_table_login);
       // xldn
       login();
    }
    private void login(){
        // tim cac doi tuong ngoai layout view
        mUsername = findViewById(R.id.username);
        mPassword = findViewById(R.id.password);
        submitLogin = findViewById(R.id.submitLogin);
        // bat sk khi nguoi dung bam dang nhap
        submitLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // lay du lieu ma nguoi dung nhap vao EditTex username va Password
                String username =mUsername.getText().toString().trim();// lay name
                String password =mPassword.getText().toString().trim();//lay pass

                if(TextUtils.isEmpty(username)){
                    mUsername.setError("user name can not be empty");
                    return;
                }
                if(TextUtils.isEmpty(password)){
                    mPassword.setError("password can not be empty");
                    return;
                }

                if(username.equals("haianh123")&& password.equals("123456")){
                    startActivity(new Intent(getApplicationContext(),MainActivity.class));
                    finish();
                }else{
                    mUsername.setError("Username or Password Invalid");
                }
            }
        });
    }
}
