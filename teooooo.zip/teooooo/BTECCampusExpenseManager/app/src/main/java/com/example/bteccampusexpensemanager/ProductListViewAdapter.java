package com.example.bteccampusexpensemanager;

import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.squareup.picasso.Picasso;

import java.util.List;

public class ProductListViewAdapter extends BaseAdapter {

    public List<ProductModel> product;

    public ProductListViewAdapter(List<ProductModel>items){
        this.product = items;
    }
    @Override
    public int getCount() {
        return product.size();
    }

    @Override
    public Object getItem(int position) {
        return product.get(position);
    }

    @Override
    public long getItemId(int position) {
        return product.get(position).idProduct;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        View viewProduct;
        if (convertView==null){
            viewProduct = View.inflate(parent.getContext(), R.layout.product_list_view, null);
        }else{
            viewProduct = convertView;
        }
        ProductModel data =(ProductModel) getItem(position);
        TextView tvIdProduct = viewProduct.findViewById(R.id.tvProductId);
        TextView tvNameProduct = viewProduct.findViewById(R.id.tvProduct_Name);
        TextView tvPriceProduct = viewProduct.findViewById(R.id.tvProduct_Price);
        ImageView imgProduct = viewProduct.findViewById(R.id.imgProduct);

        tvIdProduct.setText(String.format("%s", data.idProduct));
        tvNameProduct.setText(String.format("%s", data.nameProduct));
        tvPriceProduct.setText(String.format("%s", data.priceProduct));
        Picasso.get().load(data.imageProduct).into(imgProduct);
        return viewProduct;
    }
}
