package com.example.bteccampusexpensemanager;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

public class IntentThirdActivity extends AppCompatActivity {
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_intent_third);
        EditText edtUsername = findViewById(R.id.edtUsername);
        EditText edtPassword = findViewById(R.id.edtPassword);
        Button btnLogin = findViewById(R.id.btnLogin);

        btnLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String username = edtUsername.getText().toString().trim();
                String password = edtPassword.getText().toString().trim();
                if (TextUtils.isEmpty(username)){
                    edtUsername.setError("Enter username,please");
                    return;
                }
                if (TextUtils.isEmpty(password)){
                    edtPassword.setError("Enter password, please");
                    return;
                }
                if(username.equals("admin")&& password.equals("123")){
                    Intent intent = new Intent(IntentThirdActivity.this, MenuActivity.class);
                    Bundle bundle =new Bundle();
                    bundle.putInt("ID_USER",1);
                    bundle.putString("USER_NAME","admin@gmail.com");
                    bundle.putString("ADDRESS_USER","HA NOI");
                    bundle.putString("PHONE_USER","0968579904");
                    intent.putExtras(bundle);
                    startActivity(intent);
                    finish();
                }else{
                    edtUsername.setError("Account invalid");
                    edtPassword.setError("Account invalid");
                }
            }
        });

    }
}
