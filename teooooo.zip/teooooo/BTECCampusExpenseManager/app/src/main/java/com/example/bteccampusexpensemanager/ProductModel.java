package com.example.bteccampusexpensemanager;

public class ProductModel {
    public int idProduct;
    public String nameProduct;
    public int priceProduct;
    public String imageProduct;

    public ProductModel(int id, String name, int price, String image){
        this.idProduct = id;
        this.nameProduct = name;
        this.priceProduct = price;
        this.imageProduct = image;
    }
}
