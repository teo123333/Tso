package com.example.bteccampusexpensemanager;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

public class IntentSecondActivity extends AppCompatActivity {
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_intent_second);
        Intent intent = getIntent();
        Bundle bundle =intent.getExtras();
        if(bundle !=null){
            String myUrl = bundle.getString("MY_URL","");
            String myPhone = bundle.getString("MY_PHONE","");
            int id = bundle.getInt("ID",0);
            boolean checking = bundle.getBoolean("CHECKING",false);
            TextView tvUrl= findViewById(R.id.tvUrl);
            TextView tvPhone= findViewById(R.id.tvPhone);
            TextView tvID= findViewById(R.id.tvID);
            tvUrl.setText(myUrl);
            tvPhone.setText(myPhone);
            tvID.setText(String.format("%d", id));

        }

        Button btnGotoActivity = findViewById(R.id.btnActivity);
        btnGotoActivity.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(IntentSecondActivity.this, IntentFirstActivity.class);
                startActivity(intent);
            }
        });
    }
}
