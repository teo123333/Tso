package com.example.bteccampusexpensemanager;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;

public class SharedPreferencesActivity extends AppCompatActivity   {
    private EditText edtNumber1, edtNumber2, edtResult;
    private Button btnSum, btnClearData, btnInternal;
    private TextView tvHistory;
    private String history = "";
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_shared_preference);
        edtNumber1 = findViewById(R.id.edtNumber1);
        edtNumber2 = findViewById(R.id.edtNumber2);
        edtResult = findViewById(R.id.edtResult);
        btnSum = findViewById(R.id.btnSum);
        btnClearData = findViewById(R.id.btnClearData);
        btnInternal = findViewById(R.id.btnInternal);
        tvHistory = findViewById(R.id.tvHistory);
        edtResult.setEnabled(false);

        //doc du lieu tu shared preference
        SharedPreferences myPrefs = getSharedPreferences("myMath", MODE_PRIVATE);
        history = myPrefs.getString("plusMath", "");
        tvHistory.setText(history);

        btnInternal.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                File file = null;
                String number1 = edtNumber1.getText().toString().trim();
                String number2 = edtNumber2.getText().toString().trim();
                FileOutputStream fileOutputStream = null;
                try {
                    number1 = number1 + " ";
                    file = getFilesDir();
                    fileOutputStream = openFileOutput("asm.txt", Context.MODE_PRIVATE);
                    fileOutputStream.write(number1.getBytes());
                    fileOutputStream.write(number2.getBytes());
                    String fullPath = file + "\\asm.txt";
                    tvHistory.setText(fullPath);

                } catch (Exception ex) {
                    ex.printStackTrace();
                } finally {
                    try {
                        assert fileOutputStream != null;
                        fileOutputStream.close();
                    } catch (IOException e) {
                        throw new RuntimeException(e);
                    }
                }
            }
        });


        btnSum.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int number1 = Integer.parseInt(edtNumber1.getText().toString().trim());
                int number2 = Integer.parseInt(edtNumber2.getText().toString().trim());
                int result = number1 + number2;
                edtResult.setText(String.format("%d", result));
                history += number1 + "+" + number2 + "=" + result;
                tvHistory.setText(history);
                history += "\n";
            }
        });

        btnClearData.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                history = "";
                tvHistory.setText(history);
                edtResult.setText(history);
                edtNumber1.setText(history);
                edtNumber2.setText(history);

            }
        });
    }

    @Override
    protected void onPause() {
        super.onPause();
        // luu du lieu vao shared preferences
        // luu duoi dang la 1 .xml
        // luu duoi dang key-value
        SharedPreferences myPrefs = getSharedPreferences("myMath", MODE_PRIVATE);
        SharedPreferences.Editor editor = myPrefs.edit();
        editor.putString("plusMath", history);
        editor.apply();
    }
}