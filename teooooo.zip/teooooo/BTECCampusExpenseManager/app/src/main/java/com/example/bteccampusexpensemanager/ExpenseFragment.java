package com.example.bteccampusexpensemanager;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.ArrayAdapter;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.example.bteccampusexpensemanager.Model.Expense;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class ExpenseFragment extends Fragment {

    private EditText editTextDescription, editTextAmount;
    private Spinner spinnerCategory;
    private Button buttonAddExpense;
    private TextView textViewExpenses;

    private List<Expense> expenseList;

    @SuppressLint("MissingInflatedId")
    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_expense, container, false);

        editTextDescription = view.findViewById(R.id.Description);
        editTextAmount = view.findViewById(R.id.Amount);
        spinnerCategory = view.findViewById(R.id.Category);
        buttonAddExpense = view.findViewById(R.id.AddExpense);
        textViewExpenses = view.findViewById(R.id.Viewexpenses);

        // Setup categories
        String[] categories = {"Rent", "Groceries", "Transportation", "Entertainment", "Others"};
        ArrayAdapter<String> adapter = new ArrayAdapter<>(getContext(), android.R.layout.simple_spinner_item, categories);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerCategory.setAdapter(adapter);

        expenseList = new ArrayList<>();

        buttonAddExpense.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                addExpense();
            }
        });

        return view;
    }

    private void addExpense() {
        String description = editTextDescription.getText().toString().trim();
        String amountText = editTextAmount.getText().toString().trim();
        String category = spinnerCategory.getSelectedItem().toString();
        String date = new SimpleDateFormat("yyyy-MM-dd").format(new Date());

        if (description.isEmpty() || amountText.isEmpty()) {
            Toast.makeText(getContext(), "Please fill out all fields", Toast.LENGTH_SHORT).show();
            return;
        }

        double amount = Double.parseDouble(amountText);
        Expense expense = new Expense(description, amount, category, date);
        expenseList.add(expense);

        updateExpenseList();
        clearFields();
    }

    private void updateExpenseList() {
        StringBuilder expensesText = new StringBuilder();
        for (Expense expense : expenseList) {
            expensesText.append("Description: ").append(expense.getDescription())
                    .append(", Amount: $").append(expense.getAmount())
                    .append(", Category: ").append(expense.getCategory())
                    .append(", Date: ").append(expense.getDate())
                    .append("\n");
        }
        textViewExpenses.setText(expensesText.toString());
    }

    private void clearFields() {
        editTextDescription.setText("");
        editTextAmount.setText("");
    }
}
