package com.example.bteccampusexpensemanager;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.example.bteccampusexpensemanager.SQLite.UserDb;

public class SignupActivity extends AppCompatActivity {
    private EditText edtUsername, edtPassword, edtEmail, edtPhone;
    private Button btnSubmit;
    private UserDb userDb;
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_signup);
        edtUsername = findViewById(R.id.edtusername);
        edtPassword = findViewById(R.id.edtpassword);
        edtEmail = findViewById(R.id.edtemail);
        edtPhone = findViewById(R.id.edtphonenumber);
        btnSubmit = findViewById(R.id.btnSignUp);
        userDb = new UserDb(SignupActivity.this);
        btnSubmit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                insertUser();
                Intent intent = new Intent(SignupActivity.this, SignInActivity.class);
                startActivity(intent);
            }
        });
    }
    private void insertUser () {
        String user = edtUsername.getText().toString().trim();
        String password = edtPassword.getText().toString().trim();
        String email = edtEmail.getText().toString().trim();
        String phone = edtPhone.getText().toString().trim();
        if (TextUtils.isEmpty(user)) {
            edtUsername.setError("Username can be not empty");
            return;
        }
        if (TextUtils.isEmpty(password)) {
            edtPassword.setError("Password can be not empty");
            return;
        }
        if (TextUtils.isEmpty(email)) {
            edtEmail.setError("Email can be not empty");
            return;
        }
        if (TextUtils.isEmpty(phone)) {
            edtPhone.setError("Email can be not empty");
            return;
        }
        long result = userDb.addNewUser(user, password, email, phone);
        if (result == -1) {
            Toast.makeText(SignupActivity.this, "Sign up Failure", Toast.LENGTH_LONG).show();
            return;
        } else {
            Toast. makeText(SignupActivity.this, "Sign up Successfully", Toast.LENGTH_LONG).show();
        }
    }
}
