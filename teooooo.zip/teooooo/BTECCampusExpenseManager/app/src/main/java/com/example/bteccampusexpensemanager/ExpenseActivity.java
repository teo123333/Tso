package com.example.bteccampusexpensemanager;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;
import java.util.List;

public class ExpenseActivity extends AppCompatActivity {

    private EditText editTextDescription, editTextAmount;
    private Button buttonAddExpense, buttonEditExpense, buttonDeleteExpense;
    private TextView textViewExpenses;

    private List<String> expenseList;  // List to store expenses
    private int selectedExpenseIndex = -1; // Track the index of the selected expense

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_expense);

        editTextDescription = findViewById(R.id.Description);
        editTextAmount = findViewById(R.id.Amount);
        buttonAddExpense = findViewById(R.id.AddExpense);
        buttonEditExpense = findViewById(R.id.EditExpense);  // Initialize the Edit button
        buttonDeleteExpense = findViewById(R.id.DeleteExpense);  // Initialize the Delete button
        textViewExpenses = findViewById(R.id.Viewexpenses);

        expenseList = new ArrayList<>();

        buttonAddExpense.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                addExpense();
            }
        });

        buttonEditExpense.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                editExpense();
            }
        });

        buttonDeleteExpense.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                deleteExpense();
            }
        });

        textViewExpenses.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                selectExpenseToEditOrDelete();
            }
        });
    }

    private void addExpense() {
        String description = editTextDescription.getText().toString().trim();
        String amountText = editTextAmount.getText().toString().trim();

        if (description.isEmpty() || amountText.isEmpty()) {
            Toast.makeText(this, "Please enter description and amount", Toast.LENGTH_SHORT).show();
            return;
        }

        String expense = "Description: " + description + ", Amount: $" + amountText;
        expenseList.add(expense);
        updateExpenseTextView();

        editTextDescription.setText("");
        editTextAmount.setText("");
    }

    private void editExpense() {
        if (selectedExpenseIndex == -1) {
            Toast.makeText(this, "Please select an expense to edit", Toast.LENGTH_SHORT).show();
            return;
        }

        String description = editTextDescription.getText().toString().trim();
        String amountText = editTextAmount.getText().toString().trim();

        if (description.isEmpty() || amountText.isEmpty()) {
            Toast.makeText(this, "Please enter description and amount", Toast.LENGTH_SHORT).show();
            return;
        }

        String updatedExpense = "Description: " + description + ", Amount: $" + amountText;
        expenseList.set(selectedExpenseIndex, updatedExpense);
        updateExpenseTextView();

        editTextDescription.setText("");
        editTextAmount.setText("");
        selectedExpenseIndex = -1; // Reset after editing
    }

    private void deleteExpense() {
        if (selectedExpenseIndex == -1) {
            Toast.makeText(this, "Please select an expense to delete", Toast.LENGTH_SHORT).show();
            return;
        }

        expenseList.remove(selectedExpenseIndex);
        updateExpenseTextView();

        editTextDescription.setText("");
        editTextAmount.setText("");
        selectedExpenseIndex = -1; // Reset after deletion
    }

    private void updateExpenseTextView() {
        StringBuilder allExpenses = new StringBuilder();
        for (String expense : expenseList) {
            allExpenses.append(expense).append("\n");
        }
        textViewExpenses.setText(allExpenses.toString());
    }

    private void selectExpenseToEditOrDelete() {
        String expenses = textViewExpenses.getText().toString();
        String[] expenseArray = expenses.split("\n");

        for (int i = 0; i < expenseArray.length; i++) {
            if (expenseArray[i].contains(editTextDescription.getText().toString().trim())) {
                selectedExpenseIndex = i;
                String[] parts = expenseArray[i].split(", Amount: $");
                editTextDescription.setText(parts[0].replace("Description: ", ""));
                editTextAmount.setText(parts[1]);
                break;
            }
        }
    }
}
